#' Netlist with circuit set up of a linear regulator
#' 
#' See the vignette of RSpice or Linear Regulator Modified from P. Basso: Switched-Mode Power
#'  Supplies, 2008, Chapter 1, figure 1-2 for a visualization of the 
#'  circuit. 
"linearregulator"
